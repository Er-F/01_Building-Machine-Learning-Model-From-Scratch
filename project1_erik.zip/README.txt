Run all cells in the given order. 

It should take about 1 minute to complete.

(The magic04.data file must be in the same directory.) 
